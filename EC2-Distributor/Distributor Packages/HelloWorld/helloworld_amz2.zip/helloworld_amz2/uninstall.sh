#!/bin/bash

echo "Congratulations on your first Distributor Package!!!!"
echo "This is your Un-install Script"